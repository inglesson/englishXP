# English XP

Versión final modular para GitHub Pages.

## Cómo subir

1. Descomprime el ZIP.
2. Sube el contenido de esta carpeta al repositorio de GitHub.
3. La raíz del repositorio debe tener `index.html` y la carpeta `assets/`.
4. En GitHub Pages usa: `main / root`.

## Estructura

```
index.html
assets/
  css/app.css
  js/app.js
```

## Nota

Esta versión conserva la app actual, pero separa CSS y JS para que sea más fácil seguir iterando sin romper todo el HTML.
